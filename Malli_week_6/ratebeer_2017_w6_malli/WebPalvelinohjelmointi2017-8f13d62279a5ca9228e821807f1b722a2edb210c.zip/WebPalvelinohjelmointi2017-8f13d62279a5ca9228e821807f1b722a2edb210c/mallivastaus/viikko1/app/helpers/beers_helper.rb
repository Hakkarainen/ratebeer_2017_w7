module BeersHelper
end
