class Brewery < ActiveRecord::Base
  has_many :beers
end
