class Beer < ActiveRecord::Base
  belongs_to :brewery
end