module BeerClubsHelper
end
